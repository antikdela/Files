//
//  patchfind.h
//  TrollInstallerX
//
//  Created by Alfie on 22/03/2024.
//

#ifndef patchfind_h
#define patchfind_h

#include <stdio.h>
#include <xpf/xpf.h>

bool initialise_kernel_info(const char *kernelPath, bool iOS14);

#endif /* patchfind_h */

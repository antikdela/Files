//
//  remount.h
//  TrollInstallerX
//
//  Created by Alfie on 22/03/2024.
//

#ifndef remount_h
#define remount_h

bool remount_private_preboot(void);

#endif /* remount_h */

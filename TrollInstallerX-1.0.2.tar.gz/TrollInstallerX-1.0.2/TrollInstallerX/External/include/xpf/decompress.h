#include <stddef.h>
#include <stdint.h>
void *kdecompress(const void *src, size_t src_len, size_t *dst_len);